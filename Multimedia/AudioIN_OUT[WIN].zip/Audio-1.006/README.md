Audio
=====

PureBasic-Module for recording and playing waveform-audio
